module.exports = {
  scripts: "./website/src/js/scripts.js",
  tutorial: "./website/src/js/tutorial.js"
};
